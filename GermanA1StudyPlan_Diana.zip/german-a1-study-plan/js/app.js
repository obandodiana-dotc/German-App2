(() => {
  const $ = (sel) => document.querySelector(sel);
  const dayNumberEl = $("#day-number");
  const dayTotalEl = $("#day-total");
  const dayTitleEl = $("#day-title");
  const vocabListEl = $("#vocab-list");
  const grammarEl = $("#grammar");
  const practiceEl = $("#practice");
  const phraseEl = $("#phrase");
  const progressEl = $("#progress");
  const srsWordEl = $("#srs-word");
  const srsTrEl = $("#srs-translation");

  const prevBtn = $("#prev-day");
  const nextBtn = $("#next-day");
  const randomBtn = $("#random-day");
  const newSrsBtn = $("#new-srs");

  const total = PLAN.length;
  let current = +(localStorage.getItem("a1_current_day") || 1);

  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

  function renderDay(n){
    n = clamp(n, 1, total);
    const day = PLAN[n-1];
    dayNumberEl.textContent = n;
    dayTotalEl.textContent = total;
    dayTitleEl.textContent = day.title;
    progressEl.textContent = `${n} / ${total}`;

    // vocab
    vocabListEl.innerHTML = "";
    day.vocabulary.forEach(([de, es]) => {
      const li = document.createElement("li");
      li.textContent = `${de} — ${es}`;
      vocabListEl.appendChild(li);
    });

    grammarEl.textContent = day.grammar;
    practiceEl.textContent = day.practice;
    phraseEl.textContent = day.phrase;

    localStorage.setItem("a1_current_day", String(n));
    current = n;
  }

  function randomDay(){
    const r = Math.floor(Math.random() * total) + 1;
    renderDay(r);
  }

  function randomSRS(){
    // Flatten all vocab across the plan (limited to first 200 to keep it light)
    const all = PLAN.flatMap(d => d.vocabulary).slice(0, 200);
    if(all.length === 0){ srsWordEl.textContent = "—"; srsTrEl.textContent = "—"; return; }
    const [de, es] = all[Math.floor(Math.random() * all.length)];
    srsWordEl.textContent = de;
    srsTrEl.textContent = es;
  }

  prevBtn.addEventListener("click", () => renderDay(current - 1));
  nextBtn.addEventListener("click", () => renderDay(current + 1));
  randomBtn.addEventListener("click", randomDay);
  newSrsBtn.addEventListener("click", randomSRS);

  // Init
  window.addEventListener("DOMContentLoaded", () => {
    renderDay(current);
    randomSRS();
    $("#year").textContent = new Date().getFullYear();
  });
})();