const PLAN = [
  {
    "day": 1,
    "title": "1. Saludos y presentación",
    "vocabulary": [
      [
        "Hallo!",
        "¡Hola!"
      ],
      [
        "Guten Tag",
        "Buenos días/buen día"
      ],
      [
        "Wie heißt du?",
        "¿Cómo te llamas?"
      ],
      [
        "Ich heiße...",
        "Me llamo..."
      ],
      [
        "Ich komme aus...",
        "Soy de..."
      ]
    ],
    "grammar": "Verbo 'sein' (ich bin, du bist…) y pronombres personales (ich, du, er/sie/es…).",
    "practice": "Escribe tu presentación en 5 frases (nombre, país, ciudad, idioma, trabajo).",
    "phrase": "Ich heiße Diana und ich komme aus Costa Rica."
  },
  {
    "day": 2,
    "title": "2. Números y datos personales",
    "vocabulary": [
      [
        "eins, zwei, drei",
        "uno, dos, tres"
      ],
      [
        "Wie alt bist du?",
        "¿Cuántos años tienes?"
      ],
      [
        "Ich bin 29.",
        "Tengo 29."
      ],
      [
        "Telefonnummer",
        "número de teléfono"
      ],
      [
        "Adresse",
        "dirección"
      ]
    ],
    "grammar": "Números 0–100; preguntas W (wie, wo, was, wann).",
    "practice": "Di en voz alta tu número de teléfono y tu dirección en alemán.",
    "phrase": "Meine Telefonnummer ist ..."
  },
  {
    "day": 3,
    "title": "3. Familia",
    "vocabulary": [
      [
        "Mutter/Vater",
        "madre/padre"
      ],
      [
        "Bruder/Schwester",
        "hermano/hermana"
      ],
      [
        "Eltern",
        "padres"
      ],
      [
        "verheiratet",
        "casado/a"
      ],
      [
        "ledig",
        "soltero/a"
      ]
    ],
    "grammar": "Posesivos (mein, dein, sein/ihr).",
    "practice": "Describe a tu familia en 5 frases con posesivos.",
    "phrase": "Meine Mutter heißt ..."
  },
  {
    "day": 4,
    "title": "4. Profesiones y trabajo",
    "vocabulary": [
      [
        "Lehrer/in",
        "profesor/a"
      ],
      [
        "Arzt/Ärztin",
        "médico/a"
      ],
      [
        "Angestellte/r",
        "empleado/a"
      ],
      [
        "arbeiten",
        "trabajar"
      ],
      [
        "Büro",
        "oficina"
      ]
    ],
    "grammar": "Verbo 'arbeiten' y oraciones SVO (verbo en 2ª posición).",
    "practice": "Escribe qué haces y dónde trabajas. ",
    "phrase": "Ich arbeite im Büro."
  },
  {
    "day": 5,
    "title": "5. Ciudad y direcciones I",
    "vocabulary": [
      [
        "links/rechts",
        "izquierda/derecha"
      ],
      [
        "geradeaus",
        "todo recto"
      ],
      [
        "die Straße",
        "la calle"
      ],
      [
        "die Kreuzung",
        "el cruce"
      ],
      [
        "neben/gegenüber",
        "al lado/enfrente"
      ]
    ],
    "grammar": "Imperativo informal/usted para direcciones: Geh(en Sie) ...",
    "practice": "Da direcciones desde el parque hasta el banco en 3 pasos.",
    "phrase": "Gehen Sie geradeaus, dann links …"
  },
  {
    "day": 6,
    "title": "6. Transporte",
    "vocabulary": [
      [
        "Bus/Zug",
        "autobús/tren"
      ],
      [
        "Fahrrad/Auto",
        "bici/coche"
      ],
      [
        "fahren",
        "conducir/ir"
      ],
      [
        "Ticket/Fahrkarte",
        "billete"
      ],
      [
        "Bahnhof",
        "estación"
      ]
    ],
    "grammar": "Verbos irregulares fahren/sehen/lesen (cambio vocal).",
    "practice": "Cuenta cómo vas al trabajo (3 frases).",
    "phrase": "Ich fahre mit dem Bus zur Arbeit."
  },
  {
    "day": 7,
    "title": "7. Comida y bebida I",
    "vocabulary": [
      [
        "Brot/Brötchen",
        "pan/panecillo"
      ],
      [
        "Wasser/Kaffee",
        "agua/café"
      ],
      [
        "Mittagessen",
        "almuerzo"
      ],
      [
        "Frühstück",
        "desayuno"
      ],
      [
        "bestellen",
        "pedir (comida)"
      ]
    ],
    "grammar": "Artículos definidos/indefinidos: der/die/das – ein/eine.",
    "practice": "Di qué desayunas y almuerzas.",
    "phrase": "Zum Frühstück trinke ich Kaffee."
  },
  {
    "day": 8,
    "title": "8. Ropa y compras",
    "vocabulary": [
      [
        "Hemd/Kleid",
        "camisa/vestido"
      ],
      [
        "Hose/Schuhe",
        "pantalón/zapatos"
      ],
      [
        "tragen",
        "llevar puesto"
      ],
      [
        "kaufen",
        "comprar"
      ],
      [
        "Preis",
        "precio"
      ]
    ],
    "grammar": "Akkusativ con artículos (ich kaufe einen Mantel).",
    "practice": "Role-play: comprar una prenda (3 frases).",
    "phrase": "Ich möchte dieses Hemd, bitte."
  },
  {
    "day": 9,
    "title": "9. Casa y muebles",
    "vocabulary": [
      [
        "Wohnzimmer",
        "sala"
      ],
      [
        "Küche",
        "cocina"
      ],
      [
        "Schlafzimmer",
        "dormitorio"
      ],
      [
        "Tisch/Stuhl",
        "mesa/silla"
      ],
      [
        "Lampe",
        "lámpara"
      ]
    ],
    "grammar": "Hay/está: es gibt + Akkusativ; Präpositionen in/auf/unter.",
    "practice": "Describe tu apartamento en 4 frases.",
    "phrase": "In meiner Wohnung gibt es ein Schlafzimmer."
  },
  {
    "day": 10,
    "title": "10. Rutina diaria I",
    "vocabulary": [
      [
        "aufstehen",
        "levantarse"
      ],
      [
        "frühstücken",
        "desayunar"
      ],
      [
        "arbeiten",
        "trabajar"
      ],
      [
        "lernen",
        "estudiar"
      ],
      [
        "schlafen",
        "dormir"
      ]
    ],
    "grammar": "Verbos separables (aufstehen, anrufen): prefijo al final.",
    "practice": "Escribe tu rutina con 5 verbos separables.",
    "phrase": "Ich stehe um 7 Uhr auf."
  },
  {
    "day": 11,
    "title": "11. Tiempo y clima",
    "vocabulary": [
      [
        "sonnig",
        "soleado"
      ],
      [
        "kalt/warm",
        "frío/cálido"
      ],
      [
        "regnen",
        "llover"
      ],
      [
        "Wetter",
        "tiempo"
      ],
      [
        "Temperatur",
        "temperatura"
      ]
    ],
    "grammar": "Adverbios de tiempo: heute, morgen, am Wochenende.",
    "practice": "Cuenta el clima de hoy y planes del finde.",
    "phrase": "Heute ist es sonnig."
  },
  {
    "day": 12,
    "title": "12. Fechas y calendario",
    "vocabulary": [
      [
        "Montag–Sonntag",
        "lunes–domingo"
      ],
      [
        "Januar–Dezember",
        "enero–diciembre"
      ],
      [
        "Datum",
        "fecha"
      ],
      [
        "heute/morgen",
        "hoy/mañana"
      ],
      [
        "Woche",
        "semana"
      ]
    ],
    "grammar": "Decir la fecha: Heute ist der …; am + Tag.",
    "practice": "Escribe tu agenda de la semana en 4 frases.",
    "phrase": "Heute ist der 2. Mai."
  },
  {
    "day": 13,
    "title": "13. Aficiones y tiempo libre",
    "vocabulary": [
      [
        "lesen",
        "leer"
      ],
      [
        "Musik hören",
        "escuchar música"
      ],
      [
        "Sport machen",
        "hacer deporte"
      ],
      [
        "tanzen",
        "bailar"
      ],
      [
        "reisen",
        "viajar"
      ]
    ],
    "grammar": "Verbo mögen/gern para gustos (Ich mag…).",
    "practice": "Habla de tus hobbies (5 frases).",
    "phrase": "Ich lese gern."
  },
  {
    "day": 14,
    "title": "14. Salud básica",
    "vocabulary": [
      [
        "Kopf/Hand",
        "cabeza/mano"
      ],
      [
        "Arzt",
        "médico"
      ],
      [
        "Schmerzen",
        "dolor"
      ],
      [
        "krank/gesund",
        "enfermo/sano"
      ],
      [
        "Termin",
        "cita"
      ]
    ],
    "grammar": "Modalverben: müssen/können (Ich muss zum Arzt).",
    "practice": "Pide una cita por teléfono (guion de 3 frases).",
    "phrase": "Ich habe Kopfschmerzen."
  },
  {
    "day": 15,
    "title": "15. Restaurante",
    "vocabulary": [
      [
        "Speisekarte",
        "carta"
      ],
      [
        "bestellen",
        "pedir"
      ],
      [
        "Rechnung",
        "cuenta"
      ],
      [
        "Vorspeise",
        "entrada"
      ],
      [
        "Hauptgericht",
        "plato principal"
      ]
    ],
    "grammar": "Estructuras corteses: Ich hätte gern… / Könnte ich …?",
    "practice": "Pide una comida completa (bebida + plato + postre).",
    "phrase": "Ich hätte gern einen Kaffee, bitte."
  },
  {
    "day": 16,
    "title": "16. Direcciones II",
    "vocabulary": [
      [
        "Ampel",
        "semáforo"
      ],
      [
        "Ecke",
        "esquina"
      ],
      [
        "über die Straße",
        "cruzar la calle"
      ],
      [
        "Kreisverkehr",
        "rotonda"
      ],
      [
        "entlang",
        "a lo largo de"
      ]
    ],
    "grammar": "Preposiciones de lugar con Dativ/Akkusativ (an, auf, in).",
    "practice": "Da direcciones desde tu casa a la estación.",
    "phrase": "Gehen Sie bis zur Ampel, dann rechts."
  },
  {
    "day": 17,
    "title": "17. Correo y mensajes",
    "vocabulary": [
      [
        "E-Mail",
        "correo"
      ],
      [
        "Betreff",
        "asunto"
      ],
      [
        "Anrede",
        "saludo"
      ],
      [
        "Gruß",
        "despedida"
      ],
      [
        "schreiben",
        "escribir"
      ]
    ],
    "grammar": "Estructura de email simple; capitalización de sustantivos.",
    "practice": "Escribe un email corto de 4–5 líneas.",
    "phrase": "Liebe Frau … / Lieber Herr …"
  },
  {
    "day": 18,
    "title": "18. Descripciones físicas",
    "vocabulary": [
      [
        "groß/klein",
        "alto/bajo"
      ],
      [
        "Haare/Augen",
        "cabello/ojos"
      ],
      [
        "jung/alt",
        "joven/viejo"
      ],
      [
        "schön",
        "bonito"
      ],
      [
        "tragen",
        "llevar"
      ]
    ],
    "grammar": "Adjetivos básicos en predicado (Die Frau ist groß).",
    "practice": "Describe a 2 personas (3 frases cada una).",
    "phrase": "Er hat braune Augen."
  },
  {
    "day": 19,
    "title": "19. Planes y invitaciones",
    "vocabulary": [
      [
        "einladen",
        "invitar"
      ],
      [
        "Zeit haben",
        "tener tiempo"
      ],
      [
        "treffen",
        "quedar"
      ],
      [
        "vielleicht",
        "quizá"
      ],
      [
        "gern",
        "con gusto"
      ]
    ],
    "grammar": "Frases con hora: um + Uhr; pregunta ja/nein.",
    "practice": "Invita a alguien a un café (diálogo de 4 líneas).",
    "phrase": "Hast du Zeit am Samstag?"
  },
  {
    "day": 20,
    "title": "20. Compras II",
    "vocabulary": [
      [
        "billig/teuer",
        "barato/caro"
      ],
      [
        "Rabatt",
        "descuento"
      ],
      [
        "Größe",
        "talla"
      ],
      [
        "anprobieren",
        "probarse"
      ],
      [
        "kassieren",
        "cobrar"
      ]
    ],
    "grammar": "Preguntas W + cortesía: Wie viel kostet …?",
    "practice": "Simula compra con preguntas y respuestas.",
    "phrase": "Wie viel kostet das?"
  },
  {
    "day": 21,
    "title": "21. Rutina II (tiempos)",
    "vocabulary": [
      [
        "Uhrzeit",
        "hora"
      ],
      [
        "um/halb/viertel",
        "en punto/media/cuarto"
      ],
      [
        "früh/spät",
        "temprano/tarde"
      ],
      [
        "jeden Tag",
        "cada día"
      ],
      [
        "manchmal",
        "a veces"
      ]
    ],
    "grammar": "Orden del verbo y adverbios temporales (Heute arbeite ich…).",
    "practice": "Redacta tu día con horas exactas.",
    "phrase": "Ich arbeite heute bis 17 Uhr."
  },
  {
    "day": 22,
    "title": "22. Casa II (tareas)",
    "vocabulary": [
      [
        "putzen",
        "limpiar"
      ],
      [
        "kochen",
        "cocinar"
      ],
      [
        "waschen",
        "lavar"
      ],
      [
        "aufräumen",
        "ordenar"
      ],
      [
        "einkaufen",
        "hacer compras"
      ]
    ],
    "grammar": "Modalverben mit Infinitiv (Ich muss aufräumen).",
    "practice": "Cuenta tus tareas del hogar (5 frases).",
    "phrase": "Ich muss heute einkaufen."
  },
  {
    "day": 23,
    "title": "23. Viajes básicos",
    "vocabulary": [
      [
        "Hotel",
        "hotel"
      ],
      [
        "Reservierung",
        "reserva"
      ],
      [
        "Ticket",
        "billete"
      ],
      [
        "Pass/Reisepass",
        "pasaporte"
      ],
      [
        "Flughafen",
        "aeropuerto"
      ]
    ],
    "grammar": "Frases útiles en recepción; formularios simples.",
    "practice": "Haz una reserva ficticia (nombre, fechas, habitación).",
    "phrase": "Ich habe eine Reservierung."
  },
  {
    "day": 24,
    "title": "24. En la calle/ciudad",
    "vocabulary": [
      [
        "Apotheke",
        "farmacia"
      ],
      [
        "Bäckerei",
        "panadería"
      ],
      [
        "Supermarkt",
        "supermercado"
      ],
      [
        "Bank",
        "banco"
      ],
      [
        "Museum",
        "museo"
      ]
    ],
    "grammar": "Uso de ‘es gibt’ para ubicaciones.",
    "practice": "Di 5 lugares cerca de tu casa.",
    "phrase": "In der Nähe gibt es eine Apotheke."
  },
  {
    "day": 25,
    "title": "25. Tiempo atmosférico II",
    "vocabulary": [
      [
        "bewölkt",
        "nublado"
      ],
      [
        "windig",
        "ventoso"
      ],
      [
        "schneien",
        "nevar"
      ],
      [
        "Grad",
        "grados"
      ],
      [
        "Jahreszeit",
        "estación"
      ]
    ],
    "grammar": "Comparación simple con sehr/ziemlich/nicht so.",
    "practice": "Describe el clima de dos ciudades.",
    "phrase": "In München ist es heute sehr kalt."
  },
  {
    "day": 26,
    "title": "26. Salud II (farmacia)",
    "vocabulary": [
      [
        "Tablette",
        "pastilla"
      ],
      [
        "Rezept",
        "receta"
      ],
      [
        "Fieber",
        "fiebre"
      ],
      [
        "Husten",
        "tos"
      ],
      [
        "Allergie",
        "alergia"
      ]
    ],
    "grammar": "Ich habe … + dolor/síntoma; brauchen (necesitar).",
    "practice": "Pide consejo en una farmacia (3 frases).",
    "phrase": "Ich brauche Tabletten gegen Husten."
  },
  {
    "day": 27,
    "title": "27. Cultura y costumbres",
    "vocabulary": [
      [
        "Feiertag",
        "festivo"
      ],
      [
        "Tradition",
        "tradición"
      ],
      [
        "Weihnachten",
        "Navidad"
      ],
      [
        "Ostern",
        "Pascua"
      ],
      [
        "Karneval",
        "carnaval"
      ]
    ],
    "grammar": "Hablar en presente sobre costumbres.",
    "practice": "Cuenta una costumbre de tu país en 4 frases.",
    "phrase": "In Costa Rica feiern wir …"
  },
  {
    "day": 28,
    "title": "28. Revisión I",
    "vocabulary": [
      [
        "wiederholen",
        "repasar"
      ],
      [
        "Übung",
        "ejercicio"
      ],
      [
        "Fehler",
        "error"
      ],
      [
        "richtig/falsch",
        "correcto/incorrecto"
      ],
      [
        "Punkte",
        "puntos"
      ]
    ],
    "grammar": "Repaso de ‘sein/haben’, artículos y orden del verbo.",
    "practice": "Haz 10 frases mezclando temas de los días 1–10.",
    "phrase": "Ich habe heute viel gelernt."
  },
  {
    "day": 29,
    "title": "29. Revisión II",
    "vocabulary": [
      [
        "fragen/antworten",
        "preguntar/responder"
      ],
      [
        "sprechen",
        "hablar"
      ],
      [
        "hören",
        "escuchar"
      ],
      [
        "lesen",
        "leer"
      ],
      [
        "schreiben",
        "escribir"
      ]
    ],
    "grammar": "Repaso de modales y separables.",
    "practice": "Diálogo de 8 líneas usando direcciones y compras.",
    "phrase": "Könnten Sie mir helfen?"
  },
  {
    "day": 30,
    "title": "30. Proyecto final A1",
    "vocabulary": [
      [
        "Präsentation",
        "presentación"
      ],
      [
        "Thema",
        "tema"
      ],
      [
        "zusammenfassen",
        "resumir"
      ],
      [
        "Beispiel",
        "ejemplo"
      ],
      [
        "Ziel",
        "objetivo"
      ]
    ],
    "grammar": "Preparar mini presentación (2–3 min) sobre ti.",
    "practice": "Escribe y graba tu presentación; compártela.",
    "phrase": "Hallo! Ich heiße Diana …"
  }
];